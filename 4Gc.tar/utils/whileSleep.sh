#!/bin/bash
#This file is used by cpuOverloadTool.py utility
while true; do sleep $1 ; done 
