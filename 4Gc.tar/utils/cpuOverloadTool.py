""" 
    Author : Avinash K R
    Mail   : avinash.k_r1@alcatel-lucent.com
    Tool   : CPU overload tool
    Description: This tool can be used to load the necessary CPUs with the required percentage

"""
    

import os
import sys

def checkErrorsInCommandLineArgs(percent, cores) :

	if not(percent.isdigit()) or int(percent) <=0 or int(percent) > 100:
		print "----------------------------------------------------------------------------------------------------------------------------------------"
                print "Error : Some of the percentages mentioned in command line arguements are erraneous : [%s]. It should be positive integer less than 100." % (percent)
                print "Try \'-h\' or \'-help\' extension to know the usage"
                print "----------------------------------------------------------------------------------------------------------------------------------------"
                return -1
        for coreNumber in cores.split(','):
		first = str(coreNumber).split('-')[0]
                Len = len(str(coreNumber).split('-'))
                last = str(coreNumber).split('-')[Len - 1]
		for strCheck in first,last:
                        if not(strCheck.isdigit()):
                                print "---------------------------------------------------------------------------------------------------------------------------------"
                                print "Error : some core numbers mentioned in core block in the list of command line arguments i.e., in [%s] are not numeric" % cores
                                print "Try \'-h\' or \'-help\' extension to know the usage"
                                print "---------------------------------------------------------------------------------------------------------------------------------"
	                        return -1
		rangeList = []	
		rangeList.append(int(first))
		rangeList.append(int(last))
		rangeList.sort()
                for coreEle in range(rangeList[0], rangeList[1]+1):

			if coreEle < 1 or coreEle > 11:
                        	print "-------------------------------------------------------------------------------------------"
	                        print "Error : Some of the core numbers mentioned in core block [%s] are out of range <1-11>" % cores
        	                print "Try \'-h\' or \'-help\' extension to know the usage"
                	        print "-------------------------------------------------------------------------------------------"
                        	return -1


	if not(int(percent) == 100 or  int(percent) == 25 or  int(percent) == 50 or  int(percent) == 75):
		print "percent : %s" % percent 
                print "---------------------------------------------------------------------------------"
                print "Error : As of now, only 25, 50, 75 and 100 percent core loading is supported"
               	print "Try \'-h\' or \'-help\' extension to know the usage"
                print "---------------------------------------------------------------------------------"
		return -1

		
	return 0

def copyFiles (percent, coreNumber):

	for coreNumber in cores.split(','):
		first = int(str(coreNumber).split('-')[0])
		Len = len(str(coreNumber).split('-'))
		last = int(str(coreNumber).split('-')[Len - 1])
                rangeList = []
                rangeList.append(int(first))
                rangeList.append(int(last))
                rangeList.sort()

                for coreEle in range(rangeList[0], rangeList[1]+1):

			if int(percent) == 100:
				cmd = "/bin/cp -f /root/overload/while.sh /root/overload/load%spCpu%s\.sh" % (percent, coreEle)
                	else:
                        	cmd = "/bin/cp -f /root/overload/whileSleep.sh /root/overload/load%spCpu%s\.sh" % (percent, coreEle)
	                os.system(cmd)
	return 0
	

def launchOverload (percent, coreNumber):

        for coreNumber in cores.split(','):
                first = int(str(coreNumber).split('-')[0])
                Len = len(str(coreNumber).split('-'))
                last = int(str(coreNumber).split('-')[Len - 1])
                rangeList = []
                rangeList.append(int(first))
                rangeList.append(int(last))
                rangeList.sort()

                for coreEle in range(rangeList[0], rangeList[1]+1):

			 if int(percent) == 100:
        	        	cmd = "taskset -c  %s /root/overload/load%spCpu%s\.sh" % (coreEle, percent, coreEle) + '&'
			 else:
				if int(percent) == 25:
					sleepDuration = 0.002
				elif int(percent) == 50:
					sleepDuration = 0.0006
				elif int(percent) == 75:
					sleepDuration = 0.00015
				cmd = "taskset -c %s /root/overload/load%spCpu%s\.sh %s" % (coreEle, percent, coreEle, sleepDuration) + '&'
        	         os.system(cmd)
	return 0 


cmd = "ls /root/overload/while.sh"
whileShCheck = os.system(cmd)
cmd = "ls /root/overload/whileSleep.sh"
whileSleepShCheck = os.system(cmd)
if whileShCheck!= 0 or whileSleepShCheck!= 0:
	print "-----------------------------------------------------------------------------------------------------------------------------"
	print "Error : Unable to find required files. Please ensure to have while.sh and whileSleep.sh files in /root/overload/ directory"
	print "-----------------------------------------------------------------------------------------------------------------------------"
	quit()
			
noOfArgs = len(sys.argv) - 1
if noOfArgs % 2 != 0 and noOfArgs != 0:
	if sys.argv[1] == "-h" or sys.argv[1] == "-help":
		print "---------------------------------------------------------------------------------------------------"
		print "Usage : cpuloadSwitch.py <percentage> <coreNumber> "
		print "Example : cpuloadSwitch.py 100 2"	
		print "Example : cpuloadSwitch.py 100 1 25 5-6"	
		print "Example : cpuloadSwitch.py 50 1,3,4-6 100 2"	
		print "---------------------------------------------------------------------------------------------------"

	else:
		print "---------------------------------------------------------------------------------------------------------------------"
		print "Error : Command line arguments provided are not in a proper set. Try \'-h\' or \'-help\' extension to know the usage" 
		print "---------------------------------------------------------------------------------------------------------------------"
		quit()


elif noOfArgs == 0:

                print "---------------------------------------------------------------------------------------------------------------------"
                print "Error : Command line arguments provided are not provided. Try \'-h\' or \'-help\' extension to know the usage"
                print "---------------------------------------------------------------------------------------------------------------------"
                quit()

else:
	
	noOfPercentageGroups = noOfArgs / 2
	
	for ele in range(noOfPercentageGroups):
		
 		percent = sys.argv[ele * 2 + 1]
		cores = sys.argv[ele * 2 + 2]
		argsCheck = checkErrorsInCommandLineArgs(percent, cores)
		if int(argsCheck) != 0:
			quit()

        for ele in range(noOfPercentageGroups):

                percent = sys.argv[ele * 2 + 1]
                cores = sys.argv[ele * 2 + 2]

		copyFiles(percent, cores)
		launchOverload(percent, cores)
		
		
	quit()		







