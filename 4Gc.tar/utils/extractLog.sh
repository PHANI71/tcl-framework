#!/bin/bash

#################################################################################
#author:suresh_babu.tupakula@alcatel-lucent.com
#description : This script can be used to extract a portion of file between 
#              2 matched lines in the file
#################################################################################


# Parsing the command line arguments
outputfile="/tmp/extractlog"
while [ "$#" -gt 0 ]; do
	opt=$1
	case $opt in
	     -s)
		 shift 1
		 str1=$1;;
	     -e)
		 shift 1
		 str2=$1;;
	     -f)
		 shift 1
		 fileName=$1;;
	     -o)
		 shift 1
		 outputfile=$1;;
	     -h|--help)
		 echo "This script can be used to extract info from a file between 2 matched lines"
		 echo "For ex: Extract the info from messages file that got logged during 2 script execution"
		 echo "USAGE: extractLog.sh -f <filename> -s <str1> [-e <str2>] [-o <output filename>] [-h|--help]"
		 echo "-f -> to specify filename"
		 echo "-s -> to specify 1st string to be matched"
		 echo "-e -> to specify 2nd string to be matched. If not specified, will extract till the last line of the specified file"
		 echo "-o -> to specify output file in which the extract to be placed. Defaults to $outputfile"
		 echo "-h|--help -> to get help about this script"
		 exit 0;;
	     *)
   	         echo "INVALID SWITCH $opt"
	         echo "VALID are -s -e -f -h"
	         exit 0;;
	esac
        shift 1
done

# validating the log file existence
if [ -z "$fileName" ]; then
    echo "specify the input file name"
    exit 0
elif [ ! -f "$fileName" ]; then
    echo "File $fileName doesn't exists"
    exit 0
fi

# check if the 1st match string is specified
# also verify if it is present in the log file
if [ -z "$str1" ]; then
    echo "specify the 1st string to be matched"
    exit 0
else 
    # take only the latest match in the file
    stLine=`sed -n "/$str1/{=}" $fileName | awk 'END{print}'`
    if [ -z "$stLine" ]; then
         echo "No match found for string \"$str1\" in $fileName"
	 exit 0
    fi
fi

# check if the 2nd match string is specified
# if not specified, take the immediate script that is launched after 1st match
# if specified, check its present in the log file
# if both above conditions fail, dump from 1st match till the last line
if [ -z "$str2" ]; then
    echo "Not specified the 2nd string to be matched. Take script immediately after start string"
    str2=`sed -n "$((stLine+1)),$ {/Current Test/ {p;q} }" $fileName | sed -n 's/.*\(:.*.tcl\).*/\1/p' | sed 's/: //g'`
    echo "Next script is \"$str2\""
fi

if [ ! -z "$str2" ]; then
    endLine=`sed -n "$((stLine+1)),$ {/$str2/ {=;q} }" $fileName`
    if [ -z "$endLine" ]; then
         echo "No match found for string \"$str2\" in $fileName. "
    fi
fi

if [ -z "$endLine" ]; then
    echo "Extracting info till the last line of $fileName file"
    endLine=`wc -l $fileName | cut -d " " -f1`
fi

# Take the last match in the file
extractedLines=$((endLine - stLine + 1))

echo -e "\nDumping $extractedLines lines of info (between line#$stLine and line#$endLine) from $fileName at $outputfile"

sed -n $stLine,"$endLine"p $fileName > $outputfile 
exit 0
