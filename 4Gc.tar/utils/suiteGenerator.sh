#!/bin/sh

#################################################################################
#author:tupakula@alcatel-lucent.com
#description : This script can be used to generate a suite file for regression
#################################################################################


# Function to write the given string to the suite file
# Capable of doing formating ... if comment, no formatting
# else use awk to format the output before writing to the file
function WRITE_TO_FILE ()
{
    if [ "$2" == "comment" ]; then
         echo -e "$1"  >> $suiteFile
    elif [ "$2" == "critical" -o "$2" == "CGM" ]; then 
         echo -e "$1" |awk '{printf"%-70s %s \t %s %s\n",$1,$2,$3,$4}' >> $suiteFile
    else
    	 echo -e "$1" |awk '{printf"%-70s %s \t %s\n",$1,$2,$3}' >> $suiteFile
    fi
    return 0
}

# Function to determine the clean up scripts (like restartAtca, shutCE6 etc)
# Based on the mode of operation, scripts will be called with suitable parameters
function WRITE_CLEANUP_SCRIPTS ()
{
    if [ "$1" == "cleanup" ]; then
         WRITE_TO_FILE "lib/restartATCA.tcl $tbf CE1,typeOfBoot,soft,mvLogs,no,cleanUp,yes"
    elif [ "$1" == "reboot" ]; then
           if [ "$2" == "" -o "$noReboot" == "yes" ]; then
	        shm_mode=""
		oper_mode=""
           elif [ "$2" == "ha" ]; then
	        shm_mode="activate"
		oper_mode="   (HA)  "
	   elif [ "$2" == "simplex" ]; then
	        shm_mode="deactivate"
		oper_mode="(Simplex)"
	   fi
	   line="==============================================="
	   WRITE_TO_FILE "\n#$line   $dir $oper_mode  $line" "comment"
	   if [ ! -z "$shm_mode" ]; then 
	        WRITE_TO_FILE "lib/shutCE6.tcl $tbf CE1,$shm_mode Critical" "critical"
	   fi
	   if [ "$noReboot" != "yes" ]; then
  	        WRITE_TO_FILE "lib/restartATCA.tcl $tbf CE1 Critical\n" "critical"
           fi
    fi

    return 0
}
           
# Function to determine the script parameters and then
# use WRITE_TO_FILE to write it to the suiteFile
function WRITE_TEST_SCRIPTS ()
{
     if [ "$2" == "ha" ]; then
           args="CE1,CE2"
     else
           args="CE1"
     fi

     noOfFiles=`echo "$1" | wc -l`
     cnt=0

     for script in $1; do
	 cgm=`grep -c "generateScript" $dir/$script`
	 if [ $cgm -eq 0 ]; then 
             WRITE_TO_FILE "$dir/$script $tbf $args"
	 else
             WRITE_TO_FILE "$dir/$script $tbf $args CGM" "CGM"
	 fi
	 # If requested for a soft reboot after each script ...
         cnt=`echo $cnt + 1 | bc`
         if [ "$cleanUp" == "yes" -a $cnt -lt $noOfFiles ]; then
	      WRITE_CLEANUP_SCRIPTS "cleanup"
         fi
     done

     return 0
}


# Analyzing the comand line arguments ...
while [ "$#" -gt 0 ]; do
   opt=$1
   case $opt in
      -c)
         cleanUp="yes";;
      -d)
         shift 1
         dirList=$1;;
      -f)
         shift 1
         suiteFile="$1";;
      -i)
         ignoreCase="-i";;
      -nr)
         noReboot="yes";;
      -p)
         shift 1
         pattern="$1";;
      -r)
         cleanUp="yes";;
      -t)
         shift 1
         scriptType=$1;;
      -u)
         shift 1
         username=$1;;
      -tb)
         shift 1
         tbf=$1;;
      -h|--help)
         echo "USAGE: ./suiteGenerator.sh -d <dir> -tb <Testbed File> -f <suitefile> [-t [ha|simplex|both]] [-nr] [-p <pattern> [-i]] [-u <username>] [-h|--help]"
         echo "-c -> Adds soft reboot after every script"
         echo "-d -> To specify the modules/direcotires. (ex -d rsync or -d \"rsync vlan paec\")"
         echo "-f -> To specify the suite file name. By default it assumes Regression.txt. No need to specify extension"
	 echo "      Will create a file with .txt extension in your sqa direcotry"
         echo "-i -> Ignore case. Effective when used with -p option"
         echo "-h -> describes about this utility and options"
         echo "-nr -> Avoid adding restart scripts"
         echo "-p -> To specify the pattern ... select the files names that match with pattern. similar to grep's regexp (ex: -p *sipmon*)"
         echo "-u -> To get scripts written by a particular user. username should be the same mentiond in the \"author\" feild of the script header"
         echo "-t -> To specify the type of scritps ... "
	 echo "      ha => only ha mode scripts" 
	 echo "      simplex => only simplex mode scripts"
	 echo "      both (default) => both ha & simplex mode scripts"
         echo "-tb -> To specify the testbed file name. No need to specify the file extension (ex: -tb ybatca004)"
         exit 0;;
      *)
         echo "INVALID SWITCH $opt"
         echo "VALID are -c -d -f -h -i -nr -p -t -tb"
         echo "Try './suiteGenerator.sh -h| ./suiteGenerator.sh --help' for more information".
         exit 0;;
   esac
   shift 1
done


# Determining the current execution path and the sqa directory path
curDir=`pwd`
#sqaDir=`echo $curDir | sed -e s/"\/test.*"/\/test/g`
sqaDir=$curDir

# Removing the extensions for the testbed file and suite file if any ...
# By default we assume testbed file will be with .cfg extension and the suite
# file will be with .txt extension
# Assume default name if suiteFile in not specified in cmd line argument 
if [ -z "$suiteFile" ]; then
    suiteFile="Regression"
fi
tbf=`echo $tbf | sed -e s/"\.cfg"//g`
suiteFile=`echo $suiteFile | sed -e s/"\.txt"//g`
tb_file="$sqaDir/testbeds/$tbf.cfg"
suiteFile="$sqaDir/$suiteFile.txt"

# Validating the script directory specified by cmd line argument
if [ -z "$dirList" ]; then 
    echo -e "Please provide a valid test scripts directory name. Got \"$dirList\""
    exit 0
elif [ ${dirList} == "." ]; then
     dirList=`pwd | awk -F/ '{print $NF}'`
fi

# Validating the testbed file specified by cmd line argument
if [ -z $tbf -o ! -f $tb_file ]; then
    echo -e "File \"$tb_file\" doesn't exists. Please provide a valid testbed file name that is present in your testbeds directory. "
    exit 0
fi

# If nothing specified, write both ha and simplex mode scripts in the suite file
if [ "$scriptType" == "" ]; then
      scriptType="both"
fi

echo -e -n "Generating suite file \"$suiteFile\" for module(s) \"`echo $dirList|sed -e s/" "/,/g`\" ... "

for dir in $dirList ; do
    
    wrote=0
    dir=`echo $dir | sed -e 's/\/$//g'`
    
    # Determining the absolute path of the script directory ...
    abs_dir_path="$sqaDir/$dir"
    echo $abs_dir_path

    # Validating the absolute path of script directory specified by cmd line argument
    if [ ! -d $abs_dir_path ]; then
        echo -e "\n$abs_dir_path: No such directory. please specify correct directory name"
        exit 0
    fi

    # Seperate ha mode and simplex mode scripts 

    cd $abs_dir_path
    
    if [ -z ${username} ]; then
          filesList=`ls | grep $ignoreCase $pattern.*\.tcl`
    else 
         filesList=`grep -l "author:$username" * | grep $ignoreCase $pattern.*\.tcl`
	 userLog="with username $username"
    fi

    if [ ! -z ${pattern} ]; then
          patternLog="for pattern \"$pattern\""
    fi

    if [ -z "$filesList" ]; then
         echo -e "\nINFO: No matches found in $dir directory $patternLog $userLog"
	 continue
    fi

    if [ "$scriptType" == "both" -o "$scriptType" == "ha" ]; then
         haScripts=`grep -H -s "^proc.*device2" $filesList |cut -d : -f1`
    fi
    if [ "$scriptType" == "both" -o "$scriptType" == "simplex" ]; then
         simplexScripts=`grep -H -s "^proc.*device" $filesList | grep -v device2 |cut -d : -f1`
    fi

    # check for auto-generated scripts that will work on sourcing some original testcases
    # such scripts will not have proc/device tags in the script.
    # In such cases, to determine the script type, need to check the script type of sourced script 
    autoGenScripts=`grep -l "analyzeResult.*\[source " $filesList`
    for autoScript in $autoGenScripts ; do 
       mainFile=`grep "analyzeResult.*source " $autoScript -h | awk '{print $NF}' | sed 's/\]//g'`
       if [ `grep -c "^proc.*device1" $mainFile` -gt 0 ]; then 
            haScripts="$haScripts $autoScript"
       else
            simplexScripts="$simplexScripts $autoScript"
       fi
    done

    cd ..

    # Write files to the suiteFile


    if [ ! -z "$haScripts" ]; then
         WRITE_CLEANUP_SCRIPTS "reboot" "ha" 
         WRITE_TEST_SCRIPTS "$haScripts" "ha"
	 wrote=1
    fi

    if [ ! -z "$simplexScripts" ]; then
         WRITE_CLEANUP_SCRIPTS "reboot" "simplex" 
         WRITE_TEST_SCRIPTS "$simplexScripts" "simplex"
	 wrote=1
    fi

    if [ $wrote -eq 0 ]; then
         echo -e "\nINFO: No matches found in $dir for pattern $pattern"
    fi

done

# change permissions to the suite file
if [ -f $suiteFile ]; then
     chmod 755 $suiteFile
fi

# Printing the status only if smth is written to the suite file
if [ $wrote -ne 0 ]; then
     echo "[Completed]"
fi

exit 0
