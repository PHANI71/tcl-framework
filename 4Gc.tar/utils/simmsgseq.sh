#!/bin/bash

#################################################################################
#author:mohan.vel@alcatel-lucent.com
#description : This script is used to extract the simulator messages 
#              
#################################################################################

gw="yes"

# Parsing the command line arguments
outputfile="/tmp/simmsgseq"
while [ "$#" -gt 0 ]; do
        opt=$1
        case $opt in
             -i)
                 shift 1
                 fileName=$1;;
             -o)
                 shift 1
                 outputfile=$1;;
              -g)
                 shift 1
                  gw=$1;;
              
             -h|--help)
                 echo "This script is used to extract  henb and mme simulator message sequence in log file"
                 echo "USAGE: simmsgseq.sh -i <filename> [-o <output filename>] [-h|--help]i [-g yes/no]"
                 echo "-i -> to specify filename"
                 echo "-g -> to specify  [yes] or [no] to include gw henbgrp* output as well "
                 echo "-o -> to specify output file in which the extract to be placed. Defaults to $outputfile"
                 echo "-h|--help -> to get help about this script"
                 exit 0;;
             *)
                 echo "INVALID SWITCH $opt"
                 echo "VALID are  -i -o -g and  -h"
                 exit 0;;
        esac
        shift 1
done

# validating the log file existence
if [ -z "$fileName" ]; then
    echo "specify the input file name"
    exit 0
elif [ ! -f "$fileName" ]; then
    echo "File $fileName doesn't exists"
    exit 0
fi

if [ $gw != "yes" ];
then
sed  -n -e '/mme>/,/close/p' -e '/henb>/,/close/p' $fileName > $outputfile
else 
sed  -n -e '/mme>/,/close/p' -e '/henb>/,/close/p' -e '/HENBGRP/,/close/p' $fileName > $outputfile
fi
exit 0
