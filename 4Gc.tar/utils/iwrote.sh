#!/bin/bash
#################################################################################
#author:suresh_babu.tupakula@alcatel-lucent.com
#description : This script can be used to display/open scripts with a particular 
#              testcase id/written by a particular user/ all users etc
#              Can also used to analyze log files with a particular exit status 
#              written by a particular user
#################################################################################


# Fucntion to open the files using vi editor
function OPEN_FILES ()
{
     files=`GREP_TC withoutTc`
     if [ "${files}" != "" ]; then
          vim ${files}
     fi
     return 0
}

# Function to search the scripts wrritten by 
# a particular user/ have a particular testcase id
# arg1 specifies if testcase has to display or not in the output
function GREP_TC ()
{
     if [ ! -z "${STATUS}" ]; then
	  grep -l "Status : ${STATUS}" ${ALL_FILES}
     elif [ "${TC}" == "yes"  -a -z "${1}" ]; then
	  if [ -z "${SORT}" ]; then 
              grep -H -i "testcaseid.*${ID}" ${ALL_FILES} | awk -F ":" '{printf "%-40s \t %s\n",$NF,$1}' 
	  else
              grep -H -i "testcaseid.*${ID}" ${ALL_FILES} | awk -F ":" '{printf "%-40s \t %s\n",$NF,$1}' | sort -n 
	  fi
     else
          grep -H -i "testcaseid.*${ID}" ${ALL_FILES} | awk -F ":|-" '{print $1}'
     fi
     return 0
}


# processing the command line arguments
while [ "$#" -gt 0 ]; do
   opt=${1}
   case ${opt} in
      -t)
         TC="yes";;
      -s)
         SORT="yes";;
      -o)
         OPEN="yes";;
      -ic)
         IGNORE_CASE="-i";;
      -i)
         shift 1
         ID=$1;;
      -S)
         shift 1
         STATUS=$1;;
      -u)
         shift 1
         OWNER=$1;;
      -p)
         shift 1
         PATTERN=$1;;
      -h|--help)
         echo "USAGE: iwrote [-t [-s]] [-i <testcase Id>] [-u <script_owner_name>] [-o] [-S <status>] [-f <search_string>]"
         echo "-t -> to display testcase_ids"
         echo "-s -> to display testcases in sorted order of ids"
         echo "-i -> to show files with a particualr testcase_id"
         #echo "-f -> to search for a string in the files written by a particular user"
         echo "-u -> to see files written by a particular user"
         echo "-o -> to open files in vi"
         echo "-ic -> to ignore case "
         echo "-S -> to see log files with return status <[pass|fail|abort|notSupported|conflict|nexthop]>. shld be used with -u -o options only"
         exit 0;;
      *)
         echo "INVALID SWITCH ${opt}"
         echo "VALID are -t -s -i -u -o -h"
	 echo "Try 'iwrote -h|iwrote --help' for more information".
         exit 0;;
   esac
   shift 1
done



# Mapping the user name
if [ "${OWNER}" == "all" ]; then
    OWNER="*"
elif [ -z "${ID}" -a -z "${OWNER}" ]; then 
    OWNER=$USER
fi


if [ -z "${PATTERN}" ]; then
     PATTERN="*"
else 
     str="`ls | grep ${IGNORE_CASE} ${PATTERN}*`"
     if [ -z "${str}" ]; then
          echo "No Files matching pattern \"${PATTERN}\""
	  exit 1
     else
          PATTERN=${str}
     fi
fi

# Mapping the status ... used for log file analysis
if [ ! -z "${STATUS}" ]; then
    case ${STATUS} in
        pass)
                STATUS="PASS";;
        abort)
                STATUS="ABORT";;
        fail)
                STATUS="FAIL" ;;
        notSupported)
                STATUS="Feature Not Supported";;
        conflict)
                STATUS="System Engg to resolve the conflict";;
        nexthop)
                STATUS="NGS/NGC Defect";;
    esac
fi

if [ ! -z "${STATUS}" ]; then
     str="Author : .*${OWNER}"
else
     str="author:.*${OWNER}"
     if [ x${OWNER} == "xnone" ]; then 
         str=""
     fi
fi

ALL_FILES=`grep -l ${IGNORE_CASE} "$str" ${PATTERN}`

if [ -z "${ALL_FILES}" ]; then
    echo "No Files matched with pattern \"${PATTERN}\""
    exit 1
fi

# Executing the request
if [ "${OPEN}" == "yes" ]; then
      OPEN_FILES
else
      GREP_TC
fi

exit 0
