#!/bin/bash

#################################################################################
#author:suresh_babu.tupakula@alcatel-lucent.com
#description : This script can be used to generate suite from regression logs
#              Selective generate abort/fail scripts so as to re-run them
#################################################################################


# default values that will be used by the script
FILE=~/suiteFile.txt
TMP_FILE=/tmp/.suiteFile.tmp
STATUS=""

# Parsing the command line arguments
while [ "$#" -gt 0 ]; do
        opt=$1
        case $opt in
             -f)
                 shift 1
                 FILE=$1;;
             -s)
                 shift 1
                 STATUS="-s $1";;
             -h|--help)
                 echo "USAGE: $0 -s <status> [-f <fileName>] [-h|--help]"
		 echo "To generate suite file from the regression logs."
		 echo "Will identify the fail/abort scripts from the logs and generate the suite file"
                 echo "-s -> script execution status"
                 echo "-f -> suite file name along with location"
                 echo "-h|--help -> to get help about this script"
                 exit 0;;
             *)
                 echo "INVALID SWITCH $opt"
                 echo "VALID are -f -s -h"
                 exit 0;;
        esac
        shift 1
done

dirName=`pwd|awk -F "/" '{print $NF}'`
eval regStatus $STATUS -f | grep "/" | grep -v ":"  | cut -d "/" -f 2-| sed 's/_/ /' | sed 's/.log$/.tcl/g' > $TMP_FILE
cat $TMP_FILE | awk -v DIR=$dirName '{printf ("%s/%-70s   %-s\n",DIR,$2,$1)}' > $FILE 

echo -e "\nGenerated file is at $FILE"
