#!/bin/bash

#################################################################################
#author:suresh_babu.tupakula@alcatel-lucent.com
#description : This script can be used to analyze regression results to get a
#              summarized report. Also to get/view logs with certain exit status
#################################################################################


# Fucntion to open the files using vi editor
# arg1 specifies the status of the log file
function OPEN_FILES ()
{
     files=`GREP "$1"`
     if [ "$files" != "" ]; then
          vi $files
     fi
     return 0
}

# Function to search the log files
# arg1 specifies the status of the log file
# arg2 specifies whether files are requested or count of files are requested
function GREP ()
{
     # Map the status to the string to be matched in the log file
     status=`STR_MAPPER $1`
     if [ "$2" == "COUNT" ]; then
          echo "$ALL_FILES" | grep -e ": $status " | wc -l
     else
          echo "$ALL_FILES" | grep -e ": $status " | awk -F ":" '{print $1}'
     fi
     return 0
}

# Function to display the results after analyzing the log files
# arg1 specifies the requested object 
# (LINE= to display a line, FILES= to dispaly files, COUNT= to display no. of matches)
# arg2 specifies the status of the log file (ALL_STATUS ==> match all possible status in log files)
function DISPLAY ()
{
     if [ "$1" == "LINE" ]; then
          echo "----------------------------------------------"
          return 0
     fi
     
     if [ "$2" == "ALL_STATUS" ]; then
          STATUS_LIST='A B C D E F'
     else
          STATUS_LIST="$2"
     fi
 
     if [ "$1" == "FILES" ]; then
	  # To display the files which has requested status match
          for i in $STATUS_LIST
          do
              a=`GREP $i`
              if [ ! -z "$a" ]; then
                   for i in $a
                   do
		       # Retrieve last modified timestamp if requested
		       if [ ! -z "$DATE" ]; then
		           find $i -printf "%t" | awk '{printf "%-30s",$0}'
		       fi
		       # Retrieve author name if requested
		       if [ ! -z "$OWNER" ]; then
		           grep "Author : " $i | cut -d ":" -f2 | sed 's/ //g' | awk -F "@" '{printf "%-15s",$1}'
		       fi
		       # print file name
                       echo $i
                   done
              fi
          done
     elif [ "$1" == "COUNT" ]; then
          total=`echo "$ALL_FILES" | wc -l`

	  # To display the summary of all status if status="ALL_STATUS"
          DISPLAY "LINE"
	  for i in $STATUS_LIST
	  do
	      STATUS=`STR_MAPPER $i DISP`
	      a=`GREP $i COUNT`
  	      echo "$STATUS : $a $total" | awk '{printf"\t%-10s %c  %4d     %6.2f% \n",$1,$2,$3,$3*100/$4}'
	  done
     	  DISPLAY "LINE"

	  # Total cases
     	  if [ "$2" == "ALL_STATUS" ]; then
     	       echo "TOTAL : $total" | awk '{printf"\t%-10s %c  %4d \n",$1,$2,$3}'
               DISPLAY "LINE"
	  fi
     fi
     return 0
}

# Function to map the requested status with the standard string which will be present in the log file
# arg1 specifies the requested match
# arg2, if specified will return the pattern that can be used for display purpose. If not, it will 
#       return the pattern that has to be looked for in the log file
function STR_MAPPER ()
{
     if [ "$2" == "DISP" ]; then
          A="PASSED"
	  B="ABORTED"
	  C="FAILED "
	  D="NOT-SUP"
	  E="CONFLICT"
	  F="UNKNOWN"
     else
	  A="PASS"
	  B="ABORT"
	  C="FAIL"
	  D="Feature Not Supported"
	  E="System Engg to resolve the conflict"
	  F=""
     fi
     
     if [ ! -z "$1" ]; then
	  case "$1" in
	 	pass|A)
	 		STATUS="$A";;
	 	abort|B)
	 		STATUS="$B";;
	 	fail|C)
	 		STATUS="$C" ;;
	 	notSupported|D)
	 		STATUS="$D";;
	 	conflict|E)
	 		STATUS="$E";;
	 	unknown|F)
	 		STATUS="$F";;
	 esac
     fi
     echo $STATUS
     return 0
}

noOfOpts="$#"

# Parsing the command line arguments
while [ "$#" -gt 0 ]; do
	opt=$1
	case $opt in
	     -d)
	         FILE="yes"
	         DATE="yes";;
	     -f)
	         FILE="yes";;
	     -o)
	 	 OPEN="yes";;
             -s)
		 shift 1
		 STATUS=$1
		 case $STATUS in 
		    pass|fail|abort|notSupported|conflict|unknown);;
		    *) 
		       echo "Invalid status $STATUS"
		       echo "Valid options for \"-s\" are [pass|fail|abort|notSupported|conflict|unknown]"
		       exit 0
		 esac
		 ;;
	     -O)
	         FILE="yes"
	 	 OWNER="yes";;
	     -h|--help)
		 echo "USAGE: regStatus.sh [-f] [-s <status>] [-o] [-h|--help]"
		 echo "-d -> to display filename with last modified timestamp. will set -f option by default"
		 echo "-f -> to display filename"
		 echo "-s -> file status $validStatus"
		 echo "-o -> to open files in vi"
		 echo "-O -> to print the script author name. will set -f option by default"
		 echo "-h|--help -> to get help about this script"
		 exit 0;;
	     *)
   	         echo "INVALID SWITCH $opt"
	         echo "VALID are -d -f -s -o -O -h"
	         exit 0;;
	esac
        shift 1
done

# check for log files
ALL_FILES=`find . -name "*.log*" -type f | xargs ls -tr  | xargs grep "^Status : " | grep -v lib/ | cut -d : -f1,3-`
if [ -z "$ALL_FILES" ]; then 
      echo "No *.log* files in this directory"
      exit 0
fi

# If no args are specified display all status along with summary
if [ "$noOfOpts" -eq 0 ]; then
     DISPLAY "COUNT" "ALL_STATUS"
     exit 0
fi

# If no status requested and requested to display file names
# display all files and the summary table of the status
if [ -z "$STATUS" -a "$FILE" == "yes" ]; then
     DISPLAY "FILES" "ALL_STATUS"
     DISPLAY "COUNT" "ALL_STATUS"
# If -o option specifed with a particular status (-s) option
# open the matched files using vi editor
elif [ "$OPEN" == "yes" -a ! -z "$STATUS" ]; then
     OPEN_FILES "$STATUS"
# If status is specified (-s) without file option (-f),
# display the summary .. count of matched files
elif [ ! -z "$STATUS" -a -z "$FILE" ]; then
     DISPLAY "COUNT" "$STATUS"
# If status is specified (-s) along with file option (-f),
# display the summary and also files
elif [ ! -z "$STATUS" -a ! -z "$FILE" ]; then
     DISPLAY "FILES" "$STATUS"
     DISPLAY "COUNT" "$STATUS"
fi

exit 0
