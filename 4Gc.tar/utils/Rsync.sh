#!/bin/bash
#################################################################################
#author:suresh_babu.tupakula@alcatel-lucent.com
#description : Script to sync clearcase vob to a remote host
#################################################################################

# function to retrun the fileName
function get_file_name ()
{
   if [ -f $(readlink -f $1) ]; then 
        echo $(basename $(readlink -f $1))
   else
        echo $1
   fi
}

# function to retrun the directory name
function get_dir_name ()
{
   echo $(dirname $(readlink -f $1))
}


user_list=$USER
path=$(pwd)
sync_list=""

while [ $# -gt 0 ]; do 
      case $1 in
         -sqauser)
            user_list="$user_list sqauser";;
         *)
          sync_list="$sync_list $1";;
      esac
      shift 1
done


REMOTE_IP=135.254.210.249
RSYNC_OPTS="--recursive --exclude="*.log" --exclude=".*" --exclude unitTests/script.tcl -avzi -pog --chmod=u+rwx,o+rwx,g+rwx"

function create_directories () {
    if [ -z "$1" -o "xnet" == "x$1" ]; then
         echo -e "\nSyncing NET code ..."
         path=$CURR_SQA_DIR
         sync_list="fgw_test/test fgw_4G/4G/net fgw_common/common/net"
         # create directory on the remote 
         for i in $sync_list; do ssh $REMOTE_IP "mkdir -p $REMOTE_PATH/$i"; sync_list_new="$sync_list_new $path/$i"; done
    elif [ ! -z $1 ]; then 
         path=`get_dir_name $path/$1`
         DIR_NAME="fgw_$(echo ${path} | sed -e "s/.*fgw_//")"
         REMOTE_PATH=$REMOTE_PATH/$DIR_NAME
         # create directory on the remote 
         ssh $REMOTE_IP "mkdir -p $REMOTE_PATH"
    fi
}


# function to determine the filename length to use it as formatting string
function update_formatting_size () {
    newSize=$(echo $1 | wc -c)
    if [ -z ${F_SIZE} ]; then 
         F_SIZE=$newSize
    elif [ $newSize -gt $F_SIZE ]; then
         F_SIZE=$newSize
    fi
}

# function to determine the file(s)/directories that needs to be synced
function generate_sync_ele_list ()
{
   if [ -z "$1" ]; then 
      ele_list=$(find $path -maxdepth 1 -type d ! -path $path | grep -v ixia$ | grep -v test$ )
      rsync $RSYNC_OPTS $path/* $REMOTE_IP:$REMOTE_PATH/ > /dev/null
   else
      if [ "$1" == "." ]; then 
          ele_list=$path
      else
          ele_list=$*
      fi
   fi

   k=0
   j=0
   for i in $ele_list ; do 
      #dirName=$(get_dir_name $i)
      #eleName=$(get_file_name $i)
      eleName=$i

      # identify the files and directories that were to be copied
      if [ -f "$i" ]; then
         #eleName=${dirName}/${eleName}
         ARR_FILE[$j]=${eleName}
         j=$((j+1))
      else
         ARR_DIR[$k]=$eleName
         k=$((k+1))
     fi

     update_formatting_size $eleName
   done
}

# function to perform rsync operation for a specified element
function sync_remote ()
{
   printf "\n%s %-${F_SIZE}s %s\t" "Check and Sync" "$1" "..."
   #echo -e "\nrsync $1 $REMOTE_IP:$2/ > /dev/null"
   rsync $RSYNC_OPTS $1 $REMOTE_IP:$2/ > /dev/null
   printf "%s" "[DONE]"
}

# wrapper to perform sync operation for directories and files seperately by using "sync_remote" function
function sync_element_type ()
{
   k=0
   case ${1} in 
    file)
      if [ ${#ARR_FILE[@]} -gt $k ]; then
	  printf "\n%s\n" "Syncing files to $user@$REMOTE_IP ..."
          while [ $k -lt ${#ARR_FILE[@]} ]; do
	     sync_remote ${ARR_FILE[$k]} ${REMOTE_PATH}
             k=$((k+1))
	  done
	  printf "\n"
      fi;;
    dir)
      if [ ${#ARR_DIR[@]} -gt $k ]; then
	  printf "\n%s\n" "Syncing directories to $user@$REMOTE_IP ..."
          while [ $k -lt ${#ARR_DIR[@]} ]; do
	     sync_remote ${ARR_DIR[$k]} ${REMOTE_PATH}/$(echo ${ARR_DIR[$k]} | awk -F "/" '{$NF=""; print}' | sed 's/ /\//g')
             k=$((k+1))
	  done
	  printf "\n"
      fi;;
   esac
}

# --- main ---

for user in $user_list; do 
    REMOTE_PATH="/home/${user}/LTE"
    echo -e "\nSyncing $path to $REMOTE_PATH"

    # create directories if required
    create_directories $sync_list

    # identify the files/directories to be synced
    generate_sync_ele_list $sync_list

    # access the main directory to avoid relative path issues
    cd $path

    # syncing files if any
    sync_element_type "file"

    # syncing directories if any
    sync_element_type "dir"

done

printf "\n%s\n"  "Completed syncing"

exit 0
