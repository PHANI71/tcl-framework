#!/usr/bin/python
# code to send an eMail

import smtplib
import mimetypes
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email.Encoders import encode_base64
from email import Encoders
import os
import sys

sender_addr=sys.argv[1]
recipient_addr=sys.argv[2]
cc_addr=sys.argv[3]
subject=sys.argv[4]
content=sys.argv[5]
attach_files=""
if len(sys.argv) > 6:
   attach_files=sys.argv[6]

host="INBANSXCHHUB02.in.alcatel-lucent.com"

def getAttachment(filename):
     ctype, encoding = mimetypes.guess_type(filename)
     if ctype is None or encoding is not None:
         ctype = 'application/octet-stream'

     maintype, subtype = ctype.split('/', 1)
     fp = open(filename, 'rb')

     if maintype == 'text':
         attach = MIMEText(fp.read(),_subtype=subtype)
     elif maintype == 'message':
         attach = email.message_from_file(fp)
     elif maintype == 'image':
         attach = MIMEImage(fp.read(),_subtype=subtype)
     elif maintype == 'audio':
         attach = MIMEAudio(fp.read(),_subtype=subtype)
     else:
         print maintype, subtype
         attach = MIMEBase(maintype, subtype)
         attach.set_payload(fp.read())
         encode_base64(attach)
     fp.close
     filename=filename.split("/")
     filename=filename[-1]
     attach.add_header('Content-Disposition', 'attachment',filename=filename)
     return attach

def sendMail(host, addr, to, cc, subject, content, attach_files):

    CC=cc.split(",")
    TO=to.split(",")

    receipients = TO

    for i in CC:
	receipients.append(i)
  
    print "Sending mail from", addr, "to", receipients, "...\n"


    server = smtplib.SMTP(host)
    msg = MIMEMultipart()

    msg["Subject"] = subject
    msg["From"]    = addr
    msg["To"]      = to
    msg["Cc"]      = cc

    msg.attach( MIMEText(content) )
  
    if attach_files != "":
       attach_files=attach_files.split(",")
       for filename in attach_files:
           print "Attaching file", filename, "\n"
           attach = getAttachment(filename)
           msg.attach(attach)

    s = server.sendmail(addr, receipients, msg.as_string())
    server.quit()
    print "done."

msg="\nHi, \n\n\t" +content+ "\n"

sendMail(host, sender_addr, recipient_addr, cc_addr, subject, msg, attach_files)

